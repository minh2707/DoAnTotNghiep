﻿Khóa Luận Tốt Nghiệp
Đề Tài: XÂY DỰNG HỆ THỐNG KINH DOANH TRUC TUYẾN
GVHD: Th.S Bùi Văn Giang
SVTH: Ngô Thùy Ngọc Huyền 3.09.01.136 (SĐT:01669288639; Email: ngochuyen.it.287@gmail.com)
	Trần Thị Tâm 3.09.01.148(SDT: 01668070795; Email: sun.it158@gmail.com)